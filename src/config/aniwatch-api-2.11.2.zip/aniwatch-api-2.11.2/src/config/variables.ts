type CacheVariables = {
  CACHE_CONFIG: {
    key: string;
    duration: number;
  };
};

export type AniwatchAPIVariables = {} & CacheVariables;
